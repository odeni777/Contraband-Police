# Contraband Co-op IL2CPP — v10.6.4

Este alvo adapta o protótipo de movimento aos arquivos enviados de Contraband
Police: **Unity 2022.3.52f1, Windows x64, IL2CPP, metadata v31**. O controlador
`PlayerMovementController` e seu método `Start()` foram identificados nas
assinaturas reais do jogo. O jogo não foi executado neste ambiente; o spawn e a
captura em duas instalações reais ainda precisam de teste local.

## Preparar uma instalação de teste

1. Use uma cópia de teste da instalação e faça backup dos saves. Preserve sua
   instalação e seus saves de uso diário.
2. Instale **BepInEx 6 Unity.IL2CPP para Windows x64**, em uma build com suporte a
   metadata v31, a partir dos [builds oficiais](https://builds.bepinex.dev/projects/bepinex_be).
   O playbook fornecido relata suporte a v31 na build **be.791**; use essa build
   ou uma posterior que documente esse suporte. O loader escolhido ainda não foi
   executado com esta instalação de Contraband Police neste ambiente.
3. **Não use BepInEx 5/Mono nem o loader BepInEx 6.0.0-pre.2 para este teste.**
   O Cpp2IL incluído em pre.2 não suporta esse metadata. As DLLs pre.2 foram
   usadas somente como referência de API para compilar o plugin; isso não
   comprova compatibilidade nativa com be.791 ou outra build em execução.
4. Inicie a cópia de teste uma vez com o loader e aguarde a geração de
   `BepInEx/interop`. Confira `BepInEx/LogOutput.log`. Se a geração falhar, resolva
   o erro do loader antes de instalar o plugin.
5. Remova o protótipo Mono antigo **apenas da cópia de teste**, caso tenha sido
   instalado nela. Extraia a pasta `BepInEx/plugins/ContrabandCoop` do arquivo
   `ContrabandCoop-0.2.0-IL2CPP-v10.6.4.zip` na raiz dessa cópia.

Os binários do pacote são somente:

```text
BepInEx/plugins/ContrabandCoop/
  ContrabandCoop.Il2Cpp.dll
  ContrabandCoop.Network.dll
  LiteNetLib.dll
```

O pacote não inclui loader, `GameAssembly.dll`, metadata, wrappers interop,
UnityEngine ou arquivos do jogo. O loader gera os wrappers na sua máquina.
Não copie as referências usadas na compilação para a pasta de plugins.

## Configurar dois jogadores

O plugin cria `BepInEx/config/local.contrabandcoop.il2cpp.cfg` no primeiro início.
Também há um exemplo no pacote. Com o jogo fechado, defina uma mesma
`ConnectionKey` privada de 8 a 128 caracteres nas duas instalações.

No host:

```ini
[Network]
StartupMode = Off
Port = 9050
ConnectionKey = <mesma-chave-nas-duas-copias>
SendRateHz = 20
```

No cliente, configure também `HostAddress` com o endereço do host. Use
`127.0.0.1` para dois processos na mesma máquina; entre computadores, use o IP de
LAN/VPN do host ou uma conexão com a porta UDP do host encaminhada. O cliente usa
uma porta local efêmera.

Carregue manualmente o mesmo mapa e estados compatíveis nas duas cópias. Os
controles são:

| Tecla | Ação |
|---|---|
| F6 | Iniciar host para um parceiro |
| F7 | Conectar ao `HostAddress` configurado |
| F8 | Encerrar a sessão de rede |
| F9 | Registrar diagnóstico dos candidatos a player no log |

Se a entrada de teclado legado não estiver disponível, configure
`StartupMode = Host` no host e `StartupMode = Client` no cliente antes de iniciar.
`Off` é o padrão. O overlay pode ser desativado com `ShowOverlay = false`; ele
também é desativado se as chamadas GUI necessárias não estiverem disponíveis.

O transporte é **LiteNetLib por UDP direto**, sem Steam Spacewar, relay ou NAT
punch automático. A chave controla admissão e não criptografa o tráfego; use uma
sessão privada em rede confiável.

## O que a integração verifica

O perfil em `config/game-profile-v10.6.4.json` contém os hashes dos dois arquivos
analisados. No carregamento, o plugin lê e confere `GameAssembly.dll` e
`global-metadata.dat`. Uma instalação diferente é recusada, mesmo que mostre o
mesmo número comercial de versão. O plugin não modifica esses arquivos.

A captura usa um postfix Harmony em `PlayerMovementController.Start()`, com
verificação do tipo nativo para evitar confusão com métodos IL2CPP que compartilham
o mesmo corpo. A seleção exige um controlador ativo e o vínculo recíproco
`controller.player.mPmc.Pointer == controller.Pointer`. Se o `Start` já tiver
executado, uma busca tipada procura um único candidato válido. Candidatos
ambíguos são recusados. Não há fallback genérico de câmera nem acesso a singleton
que possa criar objetos do jogo.

O remoto é uma cápsula visual com indicador frontal, sem controles do jogo ou
collider ativo. Posição e rotação são enviadas a 20 Hz por padrão e interpoladas
na outra cópia. O avatar desaparece na desconexão, troca de cena ou após cinco
segundos sem poses. O plugin não chama `PlayerManager.SpawnPlayer`, que gerencia
o player principal do jogo.

## Compilar novamente

Use SDK .NET 8 e Python 3.9+ no workspace de desenvolvimento. O plugin gerado tem
alvo `net6.0`; o loader fornece o ambiente de execução no jogo.

Para preparar referências locais a partir dos seus arquivos da mesma instalação:

```bash
python scripts/analyze-il2cpp.py --game-assembly /caminho/GameAssembly.dll --metadata /caminho/global-metadata.dat
bash scripts/build-il2cpp.sh
```

No Windows, também é possível compilar contra as referências que um loader
compatível já gerou na sua cópia de teste:

```powershell
./scripts/build-il2cpp.ps1 -Il2CppCoreDir 'D:\TestGame\BepInEx\core' -Il2CppInteropDir 'D:\TestGame\BepInEx\interop'
```

O build e os scripts Python/Bash foram executados neste workspace Linux. O script
PowerShell foi fornecido, mas ainda não foi executado no Windows.

Os arquivos derivados do jogo ficam em `local/game-analysis/v10.6.4`, ignorado
pelo Git. Não os inclua em commits nem no ZIP do plugin.

## Evidência e teste pendente

- A análise estática identificou as assinaturas com Il2CppDumper 6.7.46 e gerou
  65 assemblies interop locais com Il2CppInterop.
- O alvo IL2CPP compilou com zero erros e avisos contra essas referências reais.
- A verificação estática do perfil passou em 12 checks, incluindo os hashes,
  tipos, assinaturas e rejeição de um arquivo de build diferente.
- A suíte do transporte passou em 12 testes e 208 asserções, com pares UDP reais
  em loopback. Esses testes não iniciam Unity.

Ainda falta executar o loader e o plugin no jogo. Nesse teste, confira o log de
carregamento, a captura do player, o material da cápsula, o alinhamento dos pés,
o movimento/rotação nos dois sentidos, reload de cena e desconexão/reconexão.
O build contra a API de referência não substitui essa validação nativa.

Este é um protótipo de **presença e movimento**. NPCs, inventário, veículos,
combate, interações, missões, saves e estado do mundo não são sincronizados.
Carregar a mesma cena não comprova que os dois mundos estão iguais.
