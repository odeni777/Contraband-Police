# Dependências

- **BepInEx 6 Unity.IL2CPP** — referências de API de compilação obtidas da
  [release oficial 6.0.0-pre.2](https://github.com/BepInEx/BepInEx/releases/tag/v6.0.0-pre.2),
  com SHA-256 fixado em `scripts/prepare-il2cpp.py`. Não redistribuído no pacote.
  O jogo com metadata v31 exige um loader mais recente com esse suporte; a API
  de referência não estabelece validação nativa da build usada para jogar.
- **Il2CppInterop** — usado somente para gerar referências locais e compilar;
  [fonte e licença](https://github.com/BepInEx/Il2CppInterop).
  Runtime e wrappers derivados do jogo não são incluídos no ZIP do plugin.
- **Il2CppDumper 6.7.46** — analisador estático de arquivos;
  [fonte](https://github.com/Perfare/Il2CppDumper). Não incluído no ZIP do plugin.
- **BepInEx 5.4.23.3** — LGPL-2.1; referências de compilação obtidas da
  [release oficial](https://github.com/BepInEx/BepInEx/releases/tag/v5.4.23.3).
  Não é redistribuído no ZIP do plugin. Instale o loader separadamente.
- **HarmonyX** — MIT; o projeto usa `0Harmony.dll` do próprio BepInEx,
  evitando instalar uma segunda cópia incompatível. Não incluído no ZIP.
- **LiteNetLib 1.3.1** — MIT;
  [fonte](https://github.com/RevenantX/LiteNetLib/tree/1.3.1).
  O pacote NuGet e seu content hash estão nos arquivos `packages.lock.json`.
- **UnityEngine.Modules 2021.3.33** — referências de compilação distribuídas no
  [NuGet](https://www.nuget.org/packages/UnityEngine.Modules/2021.3.33).
  Não incluídas na distribuição do plugin. O jogo fornece as DLLs de execução;
  confira a licença Unity aplicável ao seu uso. Esta versão de referência não
  determina nem confirma a versão instalada de Contraband Police.

Os binários do pacote IL2CPP são somente ContrabandCoop.Il2Cpp.dll,
ContrabandCoop.Network.dll e LiteNetLib.dll. O pacote Mono histórico usa
ContrabandCoop.dll. A licença MIT do LiteNetLib está em
`licenses/LiteNetLib.txt` e acompanha o ZIP.
